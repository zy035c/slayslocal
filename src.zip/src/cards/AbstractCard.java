package cards;

import core.AbstractCreature;
import core.AbstractPlayer;
import dungeons.AbstractDungeon;

/******************************************************************************
 *  所有卡的抽象父类，所有卡都必须extend这个类，并且实现构造器和use()方法。
 *  卡被打出时，向GameActionManager动作队列里添加对应的动作。
 *
 ******************************************************************************/
public abstract class AbstractCard {

    public String ID;
    public String NAME;
    public String DESCRIPTION;
    public String IMG_PATH;

    public CardType type; // 卡的种类
    public CardColor color; // 卡的颜色
    public CardRarity rarity; // 稀有度
    public CardTarget targetType; // 目标类型
    public int costForTurn; // 这回合的实际cost
    public int cost;
    public boolean freeToPlayOnce = false;
    public boolean isInAutoplay = false;

    public int baseBlock = 0;
    public int baseDamage = 0;


    public AbstractCard(String ID, String NAME, String IMG_PATH, int COST, String DESCRIPTION,
                        CardType type, CardColor color,
                        CardRarity rarity, CardTarget targetType) {

        this.ID = ID;
        this.NAME = NAME;
        this.DESCRIPTION = DESCRIPTION;
        this.IMG_PATH = IMG_PATH;
        this.cost = COST;
        this.type = type;
        this.color = color;
        this.rarity = rarity;
        this.targetType = targetType;
        // this.damageType = dType;

    }

    public boolean canPlay(AbstractCard card) {
        return true; // ???
    }

    public boolean canUse(AbstractPlayer p, AbstractCreature m) {
        if (this.type == CardType.STATUS && costForTurn < -1 // Medical Kit?
        ) {
            return false;
        }
        if (this.type == CardType.CURSE && this.costForTurn < -1 // Med Kit
        ) {
            return false;
        }
        if (cardPlayable(m) && hasEnoughEnergy()) {
            return true;
        }
        return false;
    }

    // 目标是否可选
    public boolean cardPlayable(AbstractCreature m) {
        if (((this.targetType == CardTarget.SINGLE ||
                this.targetType == CardTarget.S_AND_SINGLE) && m.isDying) ||
        AbstractDungeon.areEnemiesBasicallyDead()) {
            // this.cantUseMessage = null;
            return false;
        }
        return true;
    }

    // 能量是否足够
    public boolean hasEnoughEnergy() {
        if (AbstractDungeon.actionManager.turnHasEnded) {
            // this.cantUseMessage = TEXT[9];
            return false;
        }

        // power, relics

        // for (AbstractCard c : AbstractDungeon.player.hand.group) {
        ///* 1048 */       if (!c.canPlay(this)) {
        ///* 1049 */         return false;
        ///*      */       }
        ///*      */     }

        if (AbstractDungeon.onStagePlayer.energy >= this.costForTurn || freeToPlay() || this.isInAutoplay) {
            return true;
        }
        return false;
    }

    // 返回能量花费的String
    private String getCost() {
        if (this.cost == -1) {
            return "X";
        }
        if (freeToPlay()) {
            return "0";
        }
        return Integer.toString(this.costForTurn);
    }

    public boolean freeToPlay() {
        if (this.freeToPlayOnce) {
            return true;
        }
        // if (AbstractDungeon.player != null && AbstractDungeon.currMapNode != null &&
         //   (AbstractDungeon.getCurrRoom()).phase == AbstractRoom.RoomPhase.COMBAT &&
          //  AbstractDungeon.player.hasPower("FreeAttackPower") && this.type == CardType.ATTACK) {
         //   return true;
         //   }
        return false;
    }

    public abstract void use(AbstractPlayer paramAbstractPlayer, AbstractCreature paramAbstractMonster);


    public enum CardType {
        ATTACK, SKILL, POWER, CURSE, STATUS;
    }

    public enum CardColor {
        RED, BLUE, GREEN;
    }

    public enum CardRarity {
        BASIC, SPECIAL, COMMON, UNCOMMON, RARE, CURSE;
    }

    public enum CardTarget {
        SELF, SINGLE, PLURAL, ALL, NONE, S_AND_SINGLE, S_AND_PLURAL;
        // ENEMY, ALL_ENEMY, SELF, NONE, SELF_AND_ENEMY, ALL;
    }

}