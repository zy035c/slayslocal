package dungeons;

import cards.AbstractCard;
import core.AbstractCreature;
import core.AbstractPlayer;
import actions.common.*;
import java.util.ArrayList;
import actions.GameActionManager;
import core.Player;

/******************************************************************************
 *  当前的dungeon（游戏场景），叫做Exordium。
 *
 ******************************************************************************/

public class Exordium extends AbstractDungeon {

    public static final String ID = "Exordium";
    GameActionManager actionManager;
    public Player onStagePlayer;
    public boolean updated = false;
    public ArrayList<Player> player_list = new ArrayList<>();

    public Exordium(ArrayList<AbstractCreature> p_list) {
        super(p_list);
        actionManager = new GameActionManager();
    }

    public void init_dungeon() {
        onStagePlayer = (Player) player_list.get(0);
        actionManager.addToTop(new GainBlockAction(player_list.get(1), 15));

    }

    public void start_turn() {
        // deal cards
        actionManager.addToTop(new DiscardAllHandAction(onStagePlayer));
        actionManager.executeAction();
        actionManager.addToTop(new DrawCardAction(onStagePlayer, onStagePlayer.drawNumber, false));

        // recharge energy
        onStagePlayer.energy = 0;
        actionManager.addToTop(new GainEnergyAction(onStagePlayer.energyCap));

        actionManager.emptyQueue();
    }

    public void playCard(AbstractCard card, AbstractCreature target) {
        card.use(onStagePlayer, target);
        actionManager.phase = GameActionManager.Phase.EXECUTING_ACTIONS;
        // lose energy?
        onStagePlayer.energy -= card.costForTurn;
        actionManager.addToTop(new DiscardPlayAction(card));
        updated = true;
        actionManager.executeAction();

        actionManager.emptyQueue();
    }

    public void end_turn() {
        // discard all cards
        actionManager.addToTop(new DiscardAllHandAction(onStagePlayer));
        actionManager.emptyQueue();
        actionManager.endTurn();

        // shift player
        onStagePlayer = (Player)getEnemies().get(-1);
    }


}