package core;

import dungeons.AbstractDungeon;
import dungeons.CustomFrame;
import dungeons.CustomLabel;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public abstract class AbstractGUI {
    ArrayList<CustomLabel> label_list; // 装目前场上显示的所有手牌的CustomLabel
    private static JLabel healthBar;

    private static JLabel energyPanel;
    private CustomFrame frame;

    private class CreatureGUIset {
        CreatureGUIset(CustomFrame frame, int healthBarX, int healthBarY) {
            // init health bar
            healthBar = new JLabel();
            healthBar.setFont(new Font("Inter",Font.PLAIN,24)); // 设置字体
            healthBar.setBounds(315,439,216,33); // 设置大小
            healthBar.setVerticalAlignment(JLabel.CENTER); // 排版
            healthBar.setHorizontalAlignment(JLabel.LEFT);

            // init block bar
            blockBar = new JLabel();

            // init craeture image
            image = new JLabel();

            frame.add(healthBar);
            frame.add(blockBar);
        }

        public void updateHealthBar(int hp, int hp_max) {
            healthBar.setText(hp+"/"+hp_max);
        }

        public void updateBlockBar(int block) {
            return;
        }
    }

//    private class PlayerGUIset extends CreatureGUIset {
//
//        PlayerGUIset(CustomFrame frame, int healthBarX, int healthBarY) {
//            super(frame, healthBarX, healthBarY);
//        }
//    }

    private JLabel blockBar;
    private JLabel image;
    private JLabel buffPanel;
    public static final int[] GuiSetLayoutX = {315, 800};
    public static final int[] GuiSetLayoutY = {440, 440};

    ArrayList<CreatureGUIset> CreatureGuiSets = new ArrayList<>();
    // initialize player panel
    public AbstractGUI(CustomFrame frame) {
        this.frame = frame;
        energyPanel = new JLabel();
        int i = 0;
        for (AbstractCreature c: AbstractDungeon.getCreatures()) {
            if (i > 1) {
                break;  // only 2 player so far
            }
            CreatureGuiSets.add(new CreatureGUIset(this.frame, GuiSetLayoutX[i], GuiSetLayoutY[i]));
            i++;
        }
    }

    public static void updateBuffPanel() {}

    public static void updateBlockBar(AbstractCreature c) {

    }
    public static void reLayoutHand() {

    }
    public static void updateEnergyPanel(AbstractPlayer p) {

    }

    public static void updateHealthBar(AbstractCreature c) {

    }

    public static void deathScreen() {

    }

}
