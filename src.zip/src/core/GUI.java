package core;

import cards.AbstractCard;
import dungeons.AbstractDungeon;
import dungeons.CustomFrame;
import dungeons.CustomLabel;
import dungeons.Exordium;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class GUI extends AbstractGUI {

    ArrayList<CustomLabel> label_list; // 装目前场上显示的所有手牌的CustomLabel
    JLabel healthBar;
    JLabel healthBar2;
    JLabel blockBar;
    JLabel blockBar2;
    JLabel energyPanel;
    CustomFrame frame;
    JButton endTurnButton;
    JLabel playerPanel;

    public boolean endTurn = true;
    private ArrayList <CustomLabel> labels = new ArrayList<>();

    public GUI(CustomFrame cf) {

        this.frame = cf;
        cf.setLayout(null);

        //生命值显示
        healthBar = new JLabel("HP: 100/100"); // 设置文字
        healthBar.setFont(new Font("Inter",Font.PLAIN,24)); // 设置字体
        healthBar.setBounds(315,439,216,33); // 设置大小
        healthBar.setVerticalAlignment(JLabel.CENTER); // 排版
        healthBar.setHorizontalAlignment(JLabel.LEFT);
        frame.add(healthBar); // 把生命值添加到frame上

        //生命值显示2
        healthBar2 = new JLabel("HP: 100/100"); // 设置文字
        healthBar2.setFont(new Font("Inter",Font.PLAIN,24)); // 设置字体
        healthBar2.setBounds(700,439,216,33); // 设置大小
        healthBar2.setVerticalAlignment(JLabel.CENTER); // 排版
        healthBar2.setHorizontalAlignment(JLabel.LEFT);
        frame.add(healthBar2); // 把生命值添加到frame上

        // ENERGY
        energyPanel = new JLabel("3/3");
        energyPanel.setFont(new Font("Inter",Font.PLAIN,24));
        energyPanel.setBounds(85,540,95,49);
        energyPanel.setVerticalAlignment(JLabel.CENTER); // 排版
        energyPanel.setHorizontalAlignment(JLabel.LEFT);
        frame.add(energyPanel);

        // END TURN BUTTON
        endTurnButton = new JButton("End Turn");
        endTurnButton.setFont(new Font("Inter",Font.PLAIN,24));
        endTurnButton.setFocusable(false);
        endTurnButton.setBounds(1154,516,166,63);
        endTurnButton.setBackground(Color.lightGray);
        endTurnButton.addActionListener(e -> {
            System.out.println("Turn End. Shift Player");
            endTurn = true;
        }); // 按下之后触发
        frame.add(endTurnButton);

        // PLAYER'S NAME
        playerPanel = new JLabel();
        playerPanel.setFont(new Font("Inter",Font.PLAIN,24));
        playerPanel.setBounds(85,340,95,49);
        playerPanel.setVerticalAlignment(JLabel.CENTER); // 排版
        playerPanel.setHorizontalAlignment(JLabel.LEFT);
        frame.add(playerPanel);

        // play
        JLabel PlayArea = new JLabel();
        PlayArea.setBounds(466,151,646,453);
    }

    public void updateDungeonDisplay(Exordium dungeon) {
        playerPanel.setText(dungeon.onStagePlayer.name);
        energyPanel.setText(Integer.toString(dungeon.onStagePlayer.energy)+
                "/"+Integer.toString(dungeon.onStagePlayer.energyCap));
        healthBar.setText(Integer.toString(dungeon.onStagePlayer.health)+
                "/"+Integer.toString(dungeon.onStagePlayer.startingMaxHP));

        AbstractCreature enemy = dungeon.getEnemies().get(0);
        healthBar2.setText(Integer.toString(enemy.health)+
                "/"+Integer.toString(enemy.maxHP));
    }

    private static int CARD_Y = 676;
    private static int CARD_X_START = 160;
    private static int CARD_X_END = 1200;
    private static int CARD_X_RANGE = CARD_X_END - CARD_X_START;

    public void displayHand(Exordium dungeon) {
        int num = dungeon.onStagePlayer.hand.size();
        if (num <= 0) {
            return;
        }
        int[] x_cords = new int[num];
        for (int i = 0; i < num; i++) {
            x_cords[i] = (CARD_X_RANGE / (num + 1)) - (CustomLabel.CARD_WIDTH / 2);
            if (x_cords[i] < 0) {
                x_cords[i] = 0;
            }
            if (x_cords[i] >= CustomFrame.FRAME_WIDTH) {
                x_cords[i] = CustomFrame.FRAME_WIDTH - 50;
            }
        }

        int i = 0;
        for (AbstractCard c: AbstractDungeon.onStagePlayer.hand.deckCards) {
            CustomLabel card_label = new CustomLabel(c, dungeon, x_cords[i], CARD_Y);
            frame.add(card_label);
            labels.add(card_label);
            i++;
        }
    }

    public void updateCardDisplay(Exordium dungeon) {
        for (CustomLabel l: labels) {
            l.setVisible(false);
            l.setEnabled(false);
        }
        labels.clear();
        displayHand(dungeon);
    }

    public static void main(String[] args) {
        CustomFrame frame = new CustomFrame();
        GUI gui = new GUI(frame);

        Player p1 = new Player("p1");
        Player p2 = new Player("p2");
        ArrayList<AbstractCreature> p_list = new ArrayList<>();
        p_list.add(p1);
        p_list.add(p2);

        Exordium dungeon = new Exordium(p_list);
        dungeon.init_dungeon();
        gui.updateDungeonDisplay(dungeon);

        while(true) {
            while(gui.endTurn) {
                gui.endTurn = false;
                dungeon.start_turn();
                gui.displayHand(dungeon);
            }
        }
        while(gui.endTurn) {

            gui.endTurn = false;
            dungeon.start_turn();
            gui.displayHand(dungeon);

            while(true) {
                if (dungeon.updated) {
                    gui.updateCardDisplay(dungeon);
                    gui.updateDungeonDisplay(dungeon);
                }

            }




        }
    }

}

/*
    GUI元素:
        1 矩形 代表生命条 (HP: 100/100)
        1 圆形 代表能量 (3/3)
        2 矩形 代表抽牌弃牌堆 (Deal Pile)  (Discard Pile)
        5 矩形 代表手牌 (Hand Card 1-5)
        3或4 button (Play Selected Card) (End turn) (Deck) (Option)
 */
