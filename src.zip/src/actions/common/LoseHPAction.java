package actions.common;

import actions.AbstractGameAction;
import core.AbstractGUI;

public class LoseHPAction extends AbstractGameAction {
    public void update() {
        AbstractGUI.updateHealthBar(this.target);

    }

}
