package actions.common;
import actions.AbstractGameAction;
import core.AbstractGUI;
import core.AbstractPlayer;
import dungeons.AbstractDungeon;

public class GainEnergyAction extends AbstractGameAction {
    private int energyGain;
    public GainEnergyAction(int amount) {
        setValues(AbstractDungeon.onStagePlayer, AbstractDungeon.onStagePlayer, amount);
        this.energyGain = amount;
    }

    public void update() {
        AbstractDungeon.onStagePlayer.gainEnergy(energyGain);
        AbstractGUI.updateEnergyPanel(AbstractDungeon.onStagePlayer);
    }
}
