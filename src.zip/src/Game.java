import core.AbstractCreature;
import dungeons.CustomFrame;
import dungeons.Exordium;
import core.Player;
import core.GUI;
import javafx.application.Application;
import javafx.stage.Stage;
import java.util.ArrayList;

class Game extends Application {

    GUI gui;
    Exordium dungeon;

    public Game() {
        CustomFrame frame = new CustomFrame();
        gui = new GUI(frame);
        Player p1 = new Player("p1");
        Player p2 = new Player("p2");
        ArrayList<AbstractCreature> p_list = new ArrayList<>();
        p_list.add(p1);
        p_list.add(p2);
        dungeon = new Exordium(p_list);
    }

    @Override
    public void init() throws Exception {

    }

    @Override
    public void start(Stage primaryStage) {

    }

    @Override
    public void stop() throws Exception {

    }

    public static void main(String[] args) {

        Game game = new Game();
        game.dungeon.init_dungeon();
        game.gui.updateDungeonDisplay(game.dungeon);

        while(game.gui.endTurn) {

            game.gui.endTurn = false;

            game.dungeon.start_turn();
            game.gui.displayHand(game.dungeon);

            if (game.dungeon.updated) {
                game.gui.updateCardDisplay(game.dungeon);
                game.gui.updateDungeonDisplay(game.dungeon);
            }

        }
    }

}